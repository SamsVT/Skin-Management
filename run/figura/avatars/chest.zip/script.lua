--ช่องทางการติดต่อเพื่อแก้หรือเพิ่มรายละเอียดอื่นๆ WGTH.-- 

local squapi = require("SquAPI")

vanilla_model.CHESTPLATE:setVisible(false)
models.model.root.chrsxc.Body.chest:setPrimaryTexture("Skin")
models.model.root.chrsxc.Body.jac:setPrimaryTexture("Skin")

local chests = models.model.root.chrsxc

squapi.bewb(
	chests.Body.jac, --element
	true, --(true)doidle
	2, --(2)bendability
	.025, --(.025)stiff
	.06  --(.06)bounce
)
squapi.bewb(
	chests.Body.chest, --element
	true, --(true)doidle
	2, --(2)bendability
	.025, --(.025)stiff
	.06  --(.06)bounce
)



